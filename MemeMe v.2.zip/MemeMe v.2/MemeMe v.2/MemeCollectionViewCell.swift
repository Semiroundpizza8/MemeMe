//
//  MemeCollectionViewCell.swift
//  MemeMe v.2
//
//  Created by Benjamin Odisho on 8/23/17.
//  Copyright © 2017 Benjamin Odisho. All rights reserved.
//

import UIKit

// MARK: - VillainCollectionViewCell: UICollectionViewCell

class MemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var memeImage: UIImageView!
    
    
}
